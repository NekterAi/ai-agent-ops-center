# MEMORY.md — Premium Package Reference

Use this file like a journal for the premium package. Keep it high-level: wins, lessons, decisions. Update when you ship new files or learn something worth remembering.

- **Sections to maintain:** Overview, Decisions, Learnings.
- **Format:** Markdown bullet list, grouped by date.
- **Tip:** At the end of each sprint, summarize the code, copy, and support wins for the next iteration.
