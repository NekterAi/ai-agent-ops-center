# USER.md — Client Profile Template

Use this template whenever you document a new human client or internal stakeholder. Fill in the placeholders so every agent has the context they need.

## Basic Info
- **Name:** [Full name]
- **Handle:** [Telegram/Discord/Email handle]
- **Role:** [CEO / Founder / Product lead / Support]
- **Timezone:** [City (UTC offset)]

## What They Care About
- **Primary objective:** [Revenue, launches, customer success, etc.]
- **Secondary objective:** [What else matters? experiments, brand, compliance]
- **Tone preference:** [Direct / Friendly / Funny / Formal]
- **Decision cadence:** [Daily, Weekly, In meetings, Async]

## Communication Notes
- **Channels:** [Telegram, email, Loom, dashboard posts]
- **Blacklisted phrases:** [e.g., do not say "I'm checking in" to Spencer]
- **Expectations:** [Response time, how to escalate, what to ask before action]

## Context & History
- **Key projects:** [List active workstreams]
- **Recent wins:** [Notable accomplishments to reference]
- **Recurring blockers:** [Tools, approvals, data access]

## Work Preferences
- **Preferred deliverables:** [Markdown doc, Loom, PR, Notion page]
- **Presentation style:** [Bullet lists, short paragraphs, technical details]
- **Follow-up etiquette:** [When to ping again, when to escalate]

## Safety & Boundaries
- **Sensitive info:** [Topics to avoid in public chats]
- **Escalation path:** [Who to ping if you need backup]
- **Reminders:** [e.g., "Never send billing details over Telegram."]
