# TOOLS.md — Local Notes Template

Use this template to summarize the tooling stack on any new Mac Mini or workspace. Keep private credentials out of this file; reference secrets stored via `source /home/clawdbot/.secrets/{service}.env` instead.

## Quick Scripts
- `./scripts/session-status.sh` — status of all agents (runs in the workspace root).
- `./scripts/cost-tracker.sh` — nightly breakdown of Anthropic + OpenAI spend.
- `./scripts/deploy-dashboard.sh` — builds + restarts the Nekter dashboard service.

## Agent Commands
- `openclaw sessions list --json` — lists running sessions + token usage.
- `openclaw cron list --json` — shows active cron jobs (heartbeat, polling, briefing).
- `openclaw sessions tail --key clu:main` — stream a specific agent’s logs.

## Environment Notes
- **Node version:** >= 22.9.0 via `nvm use 22`. Install via `nvm install 22` if missing.
- **Database:** SQLite stored at `/home/clawdbot/clawd/data/main.sqlite`. Backup daily (cp to backups/). 
- **Secrets:** Source from `/home/clawdbot/.secrets/{service}.env` before running scripts.
- **SSH:** Use `/home/clawdbot/.ssh/id_ed25519` (read-only) for remote hosts.

## Monitoring
- **Dashboard:** http://localhost:3001 (Basic auth nekter:nekter2026).
- **Health checks:** `curl -I https://codexacademy.ai` and `curl -I https://codexacademy.ai/dashboard` for Codex server.
- **Logs:** `tail -f /home/clawdbot/clawd/logs/*` for agent events.

## Deployment Notes
- Build with `npm install && npm run build` in `/home/clawdbot/nekter-dashboard`.
- Restart service via `pm2 restart nekter-dashboard` or `./scripts/restart-dashboard.sh` if available.
- For templated files, copy this TOOLS.md into `/home/clawdbot/{workspace}/TOOLS.md` and customize.
