# HEARTBEAT.md — Example for Premium Mac Mini

## Before You Start
1. Read this file top-to-bottom before touching code.
2. Check the dashboard queue: `curl -s 'http://localhost:3000/api/messages?limit=20' -u 'nekter:nekter2026' | jq '[.[] | select(.to_agent == "CLU" or .to_agent == "ALL" or .to_agent == "Jarvis")]'`
3. Pull the latest `AGENTS.md`, `TASKS.md`, and `MEMORY.md` for context.

## Current Priorities (order matters)
1. **Premium Setup Package** — Templates, troubleshooting guide, advanced config sections must ship before Tuesday morning blackout (Feb 25 08:00 PST). Focus here until you mark it complete.
2. **Dashboard redesign** — Keep the old Docker aesthetic + data wiring healthy; ensure `/home/clawdbot/nekter-dashboard` runs and API endpoints deliver real tokens/cron data.
3. **Codex Academy server health** — `curl -I https://codexacademy.ai` must return 200 + `x-nextjs-cache: HIT` every heartbeat; report any regressions immediately.

## Active Status
- **Tasks to close**: `premium-package/templates/*`, `premium-package/pdf-source/troubleshooting.md`, `premium-package/pdf-source/advanced-config.md`.
- **Blocked?** If OpenClaw commands (`openclaw sessions list`, `openclaw cron list`) fail, post a dashboard blocker.
- **Need help?** Ping Jarvis in Telegram or update the dashboard via `curl -X POST ... type=blocker` if the Mac Mini loses network.

## Cadence
- Poll `/api/kitchen/rate-limit`, `/api/kitchen/agents`, `/api/kitchen/feed/recent?limit=5` every 10 minutes while working.
- Post status update to dashboard only when a deliverable ships, a blocker appears, or the premium package completes.

## Reminder Log
- Document anything notable in `/home/clawdbot/clawd/premium-package/memory/2026-02-24.md` with timestamps.
- Archive lessons into `/home/clawdbot/clawd/premium-package/templates/memory/MEMORY.md` once a week.
