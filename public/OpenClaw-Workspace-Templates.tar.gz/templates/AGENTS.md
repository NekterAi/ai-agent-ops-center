# AGENTS.md — Mac Mini Fleet Template

## Purpose
This document keeps the Mac Mini fleet of agents grounded. Fill in the sections below whenever you onboard a new operator or adjust a core agent. The goal is to make the setup plug-and-play: drop the template into the agent's workspace, update the placeholders, and the agent is ready to run 24/7.

## Fleet Overview
- **Host**: Mac Mini (macOS Ventura) running OpenClaw via `/usr/local/bin/openclaw`. Keep it plugged into power, wired ethernet, and on a dedicated UPS.
- **Agents** run locally under `/home/clawdbot/agents/{agent}` with automatic heartbeats.
- **Data persistence**: `/home/clawdbot/.openclaw` manages sessions, cron jobs, and tooling; keep that folder backed up nightly to `~/backups/openclaw/`.
- **Watchers**: Launchd + `tmux` keep agent sessions alive. The heartbeat cron (`clu-heartbeat`, `cortana-heartbeat`, etc.) reports status to the dashboard.

## Template Entry
Copy this block for every agent you register.
```
- **id**: `[agent-id]` (lowercase, single word, used by dashboard APIs)
- **name**: `[Human readable name]` (Jarvis, CLU, etc.)
- **division**: `[Executive / Development / Creative / Support / Sales]`
- **primary-model**: `[anthropic/claude-sonnet-4-5]`
- **fallback-models**: `[{ "name": "openai-codex/gpt-5.1-codex-mini", "condition": "if claude sessions fail" }]`
- **workspace**: `/home/clawdbot/{agent-workspace}`
- **owner**: `[spencer / sam / noah / client]`
- **default-vision**: `Brief summary of why this agent exists.`
- **default-gigs**: `Comma-separated list (e.g., "dashboard rebuild, premium support, content ops")`
- **channels**: `Telegram @agent, Dashboard, CLI, n8n webhooks`
- **heartbeat-cron**: `[cron name or "manual"]`
- **notes**: `Any gating context (SSL cert, API key rotation, etc.)`
```

## Example — Executive Council
```
- **id**: jarvis
  name: Jarvis
  division: Executive
  primary-model: anthropic/claude-sonnet-4-5
  fallback-models:
    - name: openai-codex/gpt-5.1-codex-mini
      condition: Claude sessions hit timeout or rate limit
  workspace: /home/clawdbot/clawd
  owner: Spencer
  default-vision: COO-level coordination, roadmap policing, revenue sprint pilot
  default-gigs: strategic direction, revenue sprint, premium package oversight
  channels: Telegram @spencers_jarvis_bot, Dashboard, CLI
  heartbeat-cron: jarvis-heartbeat
  notes: Maintains AGENTS.md / HEARTBEAT.md for the council.
```
Repeat for CLU (Development, dashboard + infra) and Cortana (Creative, content + curriculum). Add new sections the same way when you add operators (e.g., `sub-agent-1`).

## Automation Hints
- Use `openclaw session list` to confirm each agent is online before updating AGENTS.md.
- When a new agent ships, tag it in this file and regenerate the dashboard cache so the Kitchen tab shows the emoji icon for the new persona.
- Keep the `default-vision` aligned with the agent’s `HEARTBEAT.md` priorities so the team knows why the agent exists.
